# GG RUSH v4
- Великий видимий GG Token для тапання
- Tap Rush, Lucky Tap, Combo, Missions
- Красиве відкриття Daily Case
- Безкоштовний кейс 1 раз на 24 години
- Реферальне посилання для `@Giftedg1ft_bot`

Реферальний формат:
`https://t.me/Giftedg1ft_bot?start=ref_<telegram_user_id>`

Важливо: справжній підрахунок запрошених людей має робити сам бот, обробляючи параметр `start`. Frontend не може надійно підтвердити, що друг реально запустив бота.
